
import React, { useState, useEffect } from 'react';
import { AppView } from './types';
import WebhookMaker from './components/WebhookMaker';
import WebhookConsole from './components/WebhookConsole';
import Utilities from './components/Utilities';
import BotMaker from './components/BotMaker';
import { 
  Layers, LayoutDashboard, Heart, Send, Link, Wrench, ShieldCheck, Sparkles, 
  Terminal, Bot, GitBranch, Github, Command, Activity, Cpu, Zap, Globe, Shield
} from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);
  const [telemetry, setTelemetry] = useState({ cpu: 12, ram: 45, latency: 22 });

  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry({
        cpu: Math.floor(Math.random() * 15) + 5,
        ram: Math.floor(Math.random() * 10) + 40,
        latency: Math.floor(Math.random() * 30) + 15
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const renderContent = () => {
    switch (view) {
      case AppView.WEBHOOK_MAKER: return <WebhookMaker />;
      case AppView.WEBHOOK_CONSOLE: return <WebhookConsole />;
      case AppView.UTILITIES: return <Utilities />;
      case AppView.BOT_MAKER: return <BotMaker />;
      default:
        return (
          <div className="space-y-24 animate-in fade-in duration-1000">
            <div className="max-w-5xl relative">
              <div className="absolute -left-20 -top-20 w-96 h-96 bg-indigo-600/10 rounded-full blur-[120px] -z-10"></div>
              
              <div className="inline-flex items-center gap-3 px-5 py-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full mb-10 shadow-[0_0_30px_rgba(79,70,229,0.1)]">
                <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse"></div>
                <span className="text-[11px] font-black text-indigo-400 uppercase tracking-[0.4em]">Project Obsidian // Elite Edition v4</span>
              </div>
              
              <h1 className="text-[120px] font-black text-white mb-10 tracking-tighter leading-[0.8] animate-in slide-in-from-bottom-10 duration-700">
                Nexus <br/> <span className="text-transparent bg-clip-text bg-gradient-to-br from-indigo-400 via-blue-500 to-indigo-600">Forge Pro</span>
              </h1>
              
              <p className="text-3xl text-zinc-500 font-medium max-w-3xl leading-snug mb-16 animate-in slide-in-from-bottom-5 duration-700 delay-100">
                The world's most advanced Discord engineering suite. Construct logic-driven payloads, defensive bot engines, and pro-grade server architectures with cognitive AI.
              </p>
              
              <div className="flex flex-wrap gap-8 animate-in fade-in duration-700 delay-200">
                <button onClick={() => setView(AppView.WEBHOOK_MAKER)} className="px-12 py-6 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-[32px] flex items-center gap-5 shadow-[0_20px_60px_rgba(79,70,229,0.3)] transition-all hover:scale-105 active:scale-95 text-xl uppercase tracking-[0.2em] border-t border-white/20">
                  <Layers className="w-8 h-8" /> Start Forge
                </button>
                <button onClick={() => setView(AppView.BOT_MAKER)} className="px-12 py-6 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-black rounded-[32px] flex items-center gap-5 border border-zinc-800 shadow-2xl transition-all hover:scale-105 active:scale-95 text-xl uppercase tracking-[0.2em]">
                  <Bot className="w-8 h-8" /> Bot Engine
                </button>
              </div>
            </div>

            {/* Live Telemetry Panel */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 animate-in fade-in duration-1000 delay-300">
               {[
                 { label: "Gateway Status", value: "Operational", icon: <Globe className="w-4 h-4" />, color: "text-emerald-400" },
                 { label: "AI Cognitive Load", value: `${telemetry.cpu}%`, icon: <Activity className="w-4 h-4" />, color: "text-indigo-400" },
                 { label: "Sync Latency", value: `${telemetry.latency}ms`, icon: <Zap className="w-4 h-4" />, color: "text-yellow-400" },
                 { label: "Security Shield", value: "Active", icon: <Shield className="w-4 h-4" />, color: "text-red-400" }
               ].map((stat, i) => (
                 <div key={i} className="glass-card p-6 border-zinc-800/40 flex items-center gap-5">
                    <div className={`p-3 rounded-xl bg-zinc-950/50 ${stat.color} border border-current opacity-20`}>
                      {stat.icon}
                    </div>
                    <div>
                      <div className="text-[10px] font-black text-zinc-600 uppercase tracking-widest mb-0.5">{stat.label}</div>
                      <div className={`text-lg font-black tracking-tight ${stat.color}`}>{stat.value}</div>
                    </div>
                 </div>
               ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
               {[
                 { title: "Cognitive Payload Lab", icon: <Sparkles className="text-indigo-400" />, desc: "Architect elite embedded structures with buttons and select menus using ultra-low latency AI synthesis." },
                 { title: "Event Relay Simulator", icon: <GitBranch className="text-blue-400" />, desc: "High-fidelity simulation of complex Discord lifecycle events. Preview joins, leaves, and bans with data-mapped logic." },
                 { title: "Shielded Bot Engine", icon: <ShieldCheck className="text-zinc-400" />, desc: "Forge secure v14 discord.js cores with baked-in Anti-Nuke defense and professional error-resilient logic." }
               ].map((f, i) => (
                 <div key={i} className="glass-card p-12 hover:border-indigo-500/40 transition-all group relative overflow-hidden">
                    <div className="absolute -bottom-10 -right-10 opacity-[0.02] group-hover:opacity-[0.05] transition-opacity">
                      {f.icon}
                    </div>
                    <div className="w-20 h-20 bg-zinc-950 rounded-3xl flex items-center justify-center mb-10 border border-zinc-800 group-hover:scale-110 group-hover:border-indigo-500/40 transition-all duration-500">
                      <div className="scale-125">{f.icon}</div>
                    </div>
                    <h3 className="text-2xl font-black text-white mb-6 tracking-tight">{f.title}</h3>
                    <p className="text-zinc-500 font-medium text-lg leading-relaxed">{f.desc}</p>
                 </div>
               ))}
            </div>

            <div className="pt-32 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-10 opacity-30 pb-20">
               <div className="flex items-center gap-8">
                 <div className="text-[11px] font-black uppercase tracking-[0.6em] text-white">Created By Ryz Misty Production</div>
                 <div className="w-px h-8 bg-zinc-800"></div>
                 <div className="flex items-center gap-4 text-sm font-bold text-zinc-400">
                    <Github className="w-5 h-5" /> Enterprise Scale Ready
                 </div>
               </div>
               <div className="text-[11px] font-black text-zinc-700 uppercase tracking-[0.4em]">
                 Obsidian Protocol v4.2 // Final Build {new Date().getFullYear()}
               </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row overflow-hidden selection:bg-indigo-600/40">
      <aside className="w-full lg:w-96 bg-black/60 backdrop-blur-[40px] border-r border-zinc-900 p-12 flex flex-col z-50">
        <div className="flex items-center gap-5 mb-20 px-4 cursor-pointer group" onClick={() => setView(AppView.DASHBOARD)}>
          <div className="w-16 h-16 bg-indigo-600 rounded-[24px] flex items-center justify-center shadow-[0_0_40px_rgba(79,70,229,0.4)] group-hover:rotate-[15deg] group-hover:scale-110 transition-all duration-700 border-t border-white/20">
            <Command className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tighter uppercase italic">Nexus Forge</h1>
            <p className="text-[10px] text-indigo-500 font-black tracking-[0.4em] uppercase opacity-80 mt-1">Ryz Misty Intelligence</p>
          </div>
        </div>

        <nav className="flex-1 space-y-3">
          {[
            { id: AppView.DASHBOARD, label: 'Control Center', icon: <LayoutDashboard className="w-6 h-6" /> },
            { id: AppView.WEBHOOK_MAKER, label: 'Payload Architect', icon: <Layers className="w-6 h-6" /> },
            { id: AppView.BOT_MAKER, label: 'Bot Engine', icon: <Bot className="w-6 h-6" /> },
            { id: AppView.WEBHOOK_CONSOLE, label: 'Live Gateway', icon: <Send className="w-6 h-6" /> },
            { id: AppView.UTILITIES, label: 'Pro Utilities', icon: <Wrench className="w-6 h-6" /> }
          ].map(item => (
            <button 
              key={item.id} onClick={() => setView(item.id)}
              className={`w-full text-left px-8 py-5 rounded-2xl flex items-center gap-6 transition-all group ${view === item.id ? 'bg-indigo-600 text-white shadow-[0_20px_40px_rgba(79,70,229,0.3)] font-black active-ring' : 'text-zinc-600 hover:bg-zinc-900 hover:text-white font-bold'}`}
            >
              <div className={`transition-transform duration-300 ${view === item.id ? 'scale-110' : 'group-hover:translate-x-1'}`}>
                {item.icon}
              </div>
              <span className="text-sm uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-16 border-t border-zinc-900">
          <div className="flex items-center gap-4 px-4 bg-zinc-950/50 p-4 rounded-2xl border border-zinc-900">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
              <Activity className="w-5 h-5 text-emerald-500 animate-pulse" />
            </div>
            <div>
              <div className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">
                Uplink Active
              </div>
              <div className="text-[9px] text-zinc-700 font-bold uppercase mt-0.5">
                Cluster: us-east-4
              </div>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto relative bg-[#050505] custom-scrollbar">
        <div className="max-w-[1400px] mx-auto p-12 lg:p-24 relative z-10">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;
