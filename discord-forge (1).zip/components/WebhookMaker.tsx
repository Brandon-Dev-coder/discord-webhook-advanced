
import React, { useState, useEffect } from 'react';
import { 
  Send, Plus, Trash2, Layers, Sparkles, Book, Save, Check, X, AlertCircle, 
  Zap, Target, Info, Search, UserPlus, UserMinus, Rocket, ShieldAlert, 
  Edit, Trash, Trophy, Mic, Hash, MessageSquarePlus, Link as LinkIcon,
  MousePointer2, ExternalLink, Settings2
} from 'lucide-react';
import { WebhookPayload, WebhookEmbed, WebhookTemplate, DiscordEvent, ComponentType, ButtonStyle, WebhookButton, WebhookActionRow } from '../types';
import CodeBlock from './CodeBlock';
import { suggestWebhookScenario, generateEventPayload } from '../services/geminiService';

const EVENT_CONFIG: Record<DiscordEvent, { icon: React.ReactNode, label: string, color: string }> = {
  [DiscordEvent.GENERIC]: { icon: <Zap className="w-4 h-4" />, label: 'Generic Broadcast', color: 'text-blue-400' },
  [DiscordEvent.MEMBER_JOIN]: { icon: <UserPlus className="w-4 h-4" />, label: 'Member Join', color: 'text-green-400' },
  [DiscordEvent.MEMBER_LEAVE]: { icon: <UserMinus className="w-4 h-4" />, label: 'Member Leave', color: 'text-red-400' },
  [DiscordEvent.MEMBER_BAN]: { icon: <ShieldAlert className="w-4 h-4" />, label: 'Security Ban', color: 'text-red-600' },
  [DiscordEvent.SERVER_BOOST]: { icon: <Rocket className="w-4 h-4" />, label: 'Server Boost', color: 'text-pink-400' },
  [DiscordEvent.MESSAGE_EDIT]: { icon: <Edit className="w-4 h-4" />, label: 'Message Edit', color: 'text-yellow-400' },
  [DiscordEvent.MESSAGE_DELETE]: { icon: <Trash className="w-4 h-4" />, label: 'Message Delete', color: 'text-gray-400' },
  [DiscordEvent.LEVEL_UP]: { icon: <Trophy className="w-4 h-4" />, label: 'Level Up', color: 'text-yellow-500' },
  [DiscordEvent.SECURITY_ALERT]: { icon: <ShieldAlert className="w-4 h-4" />, label: 'Security Intel', color: 'text-red-500' },
  [DiscordEvent.VOICE_JOIN]: { icon: <Mic className="w-4 h-4" />, label: 'Voice Connect', color: 'text-indigo-400' },
  [DiscordEvent.THREAD_CREATE]: { icon: <Hash className="w-4 h-4" />, label: 'Thread Sync', color: 'text-blue-300' },
  [DiscordEvent.REACTION_ADD]: { icon: <MessageSquarePlus className="w-4 h-4" />, label: 'Reaction Signal', color: 'text-orange-400' }
};

const BUTTON_STYLES = [
  { value: ButtonStyle.PRIMARY, label: 'Primary (Blurple)', color: 'bg-[#5865F2]' },
  { value: ButtonStyle.SECONDARY, label: 'Secondary (Grey)', color: 'bg-[#4E5058]' },
  { value: ButtonStyle.SUCCESS, label: 'Success (Green)', color: 'bg-[#248046]' },
  { value: ButtonStyle.DANGER, label: 'Danger (Red)', color: 'bg-[#DA373C]' },
  { value: ButtonStyle.LINK, label: 'Link', color: 'bg-zinc-700' },
];

const WebhookMaker: React.FC = () => {
  const [url, setUrl] = useState('');
  const [payload, setPayload] = useState<WebhookPayload>({
    username: 'Forge Intelligence',
    content: 'Awaiting event trigger configuration...',
    embeds: [],
    components: []
  });
  const [activeTrigger, setActiveTrigger] = useState<DiscordEvent>(DiscordEvent.GENERIC);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview' | 'json'>('edit');
  const [sending, setSending] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [status, setStatus] = useState<{ type: 'success' | 'error', msg: string } | null>(null);

  const showStatus = (type: 'success' | 'error', msg: string) => {
    setStatus({ type, msg });
    setTimeout(() => setStatus(null), 3000);
  };

  const handleMagicFill = async () => {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    try {
      const suggested = activeTrigger === DiscordEvent.GENERIC 
        ? await suggestWebhookScenario(aiPrompt)
        : await generateEventPayload(activeTrigger, aiPrompt);
      setPayload(prev => ({ ...prev, ...suggested }));
      setActiveTab('preview');
      showStatus('success', 'Intelligence Sync Complete');
    } catch (e) {
      showStatus('error', 'Forge AI Interruption');
    } finally {
      setAiLoading(false);
    }
  };

  const addActionRow = () => {
    if ((payload.components?.length || 0) >= 5) return;
    const newRow: WebhookActionRow = { type: ComponentType.ACTION_ROW, components: [] };
    setPayload(p => ({ ...p, components: [...(p.components || []), newRow] }));
  };

  const addButton = (rowIndex: number) => {
    const row = payload.components?.[rowIndex];
    if (!row || row.components.length >= 5) return;
    const newBtn: WebhookButton = {
      type: ComponentType.BUTTON,
      style: ButtonStyle.PRIMARY,
      label: 'New Button',
      custom_id: `btn_${Math.random().toString(36).substr(2, 5)}`
    };
    const newComponents = [...(payload.components || [])];
    newComponents[rowIndex] = { ...row, components: [...row.components, newBtn] };
    setPayload(p => ({ ...p, components: newComponents }));
  };

  const updateButton = (rowIndex: number, btnIndex: number, updates: Partial<WebhookButton>) => {
    const newComponents = [...(payload.components || [])];
    const row = { ...newComponents[rowIndex] };
    const btn = { ...row.components[btnIndex], ...updates };
    row.components[btnIndex] = btn as WebhookButton;
    newComponents[rowIndex] = row;
    setPayload(p => ({ ...p, components: newComponents }));
  };

  const deleteButton = (rowIndex: number, btnIndex: number) => {
    const newComponents = [...(payload.components || [])];
    const row = { ...newComponents[rowIndex] };
    row.components = row.components.filter((_, i) => i !== btnIndex);
    newComponents[rowIndex] = row;
    setPayload(p => ({ ...p, components: newComponents }));
  };

  const renderPlaceholder = (text: string) => {
    if (!text) return null;
    return text.split(/(\{.*?\})/g).map((part, i) => 
      part.startsWith('{') ? <span key={i} className="text-indigo-400 font-bold px-1 bg-indigo-500/10 rounded">{part}</span> : part
    );
  };

  const sendWebhook = async () => {
    if (!url) return showStatus('error', 'Destination Missing');
    setSending(true);
    try {
      const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      res.ok ? showStatus('success', 'Payload Dispatched') : showStatus('error', 'Protocol Error');
    } catch { showStatus('error', 'Uplink Failed'); }
    finally { setSending(false); }
  };

  return (
    <div className="space-y-12 animate-in fade-in duration-700 pb-20">
      {/* Premium Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-zinc-900 pb-10">
        <div>
          <div className="flex items-center gap-4 mb-3">
            <div className="p-3 bg-indigo-600/10 rounded-2xl border border-indigo-500/20 shadow-[0_0_30px_rgba(79,70,229,0.1)]">
              <Layers className="w-10 h-10 text-indigo-400" />
            </div>
            <div>
              <h1 className="text-5xl font-black tracking-tighter uppercase italic bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent">Nexus Forge Pro</h1>
              <p className="text-[10px] font-black tracking-[0.4em] text-indigo-500 uppercase mt-1">Multi-Component Payload Architect</p>
            </div>
          </div>
          <p className="text-zinc-500 font-medium max-w-xl">The elite standard for Discord interactions. Build complex messages with embeds, buttons, and AI-optimized logic.</p>
        </div>
        <div className="flex bg-zinc-900/50 backdrop-blur-xl border border-zinc-800 p-1.5 rounded-2xl shadow-2xl">
          {(['edit', 'preview', 'json'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)} className={`px-8 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/40' : 'text-zinc-500 hover:text-zinc-300'}`}>
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-7 space-y-12">
          
          {/* Advanced Trigger Selection */}
          <div className="glass-card p-10 glow-hover transition-all relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
              <Settings2 className="w-24 h-24 rotate-12" />
            </div>
            <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-500 mb-8 flex items-center gap-3">
              <Target className="w-5 h-5 text-indigo-500" /> Interaction Logic Mapping
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {Object.entries(EVENT_CONFIG).map(([key, cfg]) => (
                <button 
                  key={key} 
                  onClick={() => setActiveTrigger(key as DiscordEvent)}
                  className={`flex flex-col items-center justify-center p-6 rounded-2xl border transition-all gap-3 ${activeTrigger === key ? 'bg-indigo-600/10 border-indigo-500/50 active-ring shadow-lg' : 'bg-zinc-950/40 border-zinc-800 hover:border-zinc-700'}`}
                >
                  <div className={activeTrigger === key ? cfg.color : 'text-zinc-600'}>{cfg.icon}</div>
                  <span className={`text-[10px] font-black uppercase tracking-tight text-center ${activeTrigger === key ? 'text-white' : 'text-zinc-600'}`}>{cfg.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* AI Orchestrator */}
          <div className="glass-card p-10 border-indigo-500/10 bg-gradient-to-br from-zinc-900/50 to-indigo-950/20">
              <div className="flex items-center gap-5 mb-8">
                <div className="w-14 h-14 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-[0_0_30px_rgba(79,70,229,0.3)]">
                  <Sparkles className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white tracking-tight">AI Cognitive Synthesis</h3>
                  <p className="text-xs text-zinc-500 font-medium">Describe your message intent for automated structuring.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <input 
                  type="text" value={aiPrompt} onChange={e => setAiPrompt(e.target.value)}
                  placeholder="Ex: A ticket system welcome message with a verify button and professional blue embed..."
                  className="flex-1 bg-zinc-950 border border-zinc-800 rounded-2xl px-6 py-5 text-sm focus:border-indigo-500 outline-none transition-all placeholder:text-zinc-800 font-medium"
                />
                <button 
                  onClick={handleMagicFill} disabled={aiLoading || !aiPrompt.trim()}
                  className="px-10 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-indigo-600/40 transition-all active:scale-95"
                >
                  {aiLoading ? 'Synthesizing...' : 'Generate'}
                </button>
              </div>
          </div>

          {/* Component Builder */}
          <div className="glass-card p-10 space-y-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-500 flex items-center gap-3">
                <MousePointer2 className="w-5 h-5 text-emerald-500" /> Visual Component Lab
              </h3>
              <button 
                onClick={addActionRow}
                disabled={(payload.components?.length || 0) >= 5}
                className="px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-widest border border-emerald-500/20 rounded-xl transition-all disabled:opacity-20"
              >
                + Action Row
              </button>
            </div>

            <div className="space-y-6">
              {payload.components?.map((row, rIdx) => (
                <div key={rIdx} className="p-6 bg-zinc-950/50 border border-zinc-800 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-black text-zinc-700 uppercase tracking-widest">Row {rIdx + 1} // max 5 components</span>
                    <div className="flex gap-2">
                      <button onClick={() => addButton(rIdx)} className="p-1.5 hover:bg-emerald-500/10 rounded-lg transition-all text-emerald-500">
                        <Plus className="w-4 h-4" />
                      </button>
                      <button onClick={() => setPayload(p => ({ ...p, components: p.components?.filter((_, i) => i !== rIdx) }))} className="p-1.5 hover:bg-red-500/10 rounded-lg transition-all text-red-500">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {row.components.map((btn, bIdx) => (
                      <div key={bIdx} className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl space-y-3 relative group/btn">
                        <button onClick={() => deleteButton(rIdx, bIdx)} className="absolute top-2 right-2 opacity-0 group-hover/btn:opacity-100 text-red-500/40 hover:text-red-500 transition-all p-1">
                          <Trash className="w-3 h-3" />
                        </button>
                        <div className="space-y-2">
                          <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Label</label>
                          <input 
                            type="text" value={btn.label} 
                            onChange={e => updateButton(rIdx, bIdx, { label: e.target.value })} 
                            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs text-zinc-300 outline-none focus:border-indigo-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Style</label>
                          <div className="flex flex-wrap gap-1">
                            {BUTTON_STYLES.map(style => (
                              <button 
                                key={style.value}
                                onClick={() => updateButton(rIdx, bIdx, { style: style.value })}
                                className={`w-6 h-6 rounded ${style.color} border-2 transition-all ${btn.style === style.value ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-40 hover:opacity-100'}`}
                                title={style.label}
                              />
                            ))}
                          </div>
                        </div>
                        {btn.style === ButtonStyle.LINK ? (
                          <div className="space-y-2">
                            <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">URL</label>
                            <input 
                              type="text" value={btn.url || ''} 
                              onChange={e => updateButton(rIdx, bIdx, { url: e.target.value })} 
                              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs text-zinc-300 outline-none focus:border-indigo-500"
                            />
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Custom ID</label>
                            <input 
                              type="text" value={btn.custom_id || ''} 
                              onChange={e => updateButton(rIdx, bIdx, { custom_id: e.target.value })} 
                              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs text-zinc-300 outline-none focus:border-indigo-500"
                            />
                          </div>
                        )}
                      </div>
                    ))}
                    {row.components.length === 0 && (
                      <div className="col-span-full py-10 flex flex-col items-center justify-center border border-dashed border-zinc-800 rounded-xl opacity-20">
                        <Plus className="w-6 h-6 mb-2" />
                        <span className="text-[10px] font-black uppercase">No Components in Row</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {(payload.components?.length || 0) === 0 && (
                <div className="py-12 flex flex-col items-center justify-center bg-zinc-950/20 border border-zinc-800 rounded-3xl opacity-30">
                   <Settings2 className="w-10 h-10 mb-4" />
                   <p className="text-xs font-bold">No interactive components configured.</p>
                </div>
              )}
            </div>
          </div>

          <div className="glass-card p-10 space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
               <div className="space-y-4">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Gateway Endpoint</label>
                  <div className="relative">
                    <input type="text" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://discord.com/api/webhooks/..." className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-5 text-xs font-mono text-zinc-500 focus:border-indigo-500 outline-none transition-all shadow-inner" />
                    <LinkIcon className="absolute right-5 top-4.5 w-5 h-5 text-zinc-800" />
                  </div>
               </div>
               <div className="space-y-4">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Bot Identity Overwrite</label>
                  <input type="text" value={payload.username} onChange={e => setPayload({...payload, username: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-5 text-xs focus:border-indigo-500 outline-none transition-all font-medium" />
               </div>
            </div>
            <div className="space-y-4">
               <div className="flex items-center justify-between">
                 <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Dynamic Payload Content</label>
                 <span className="text-[9px] text-zinc-700 font-bold uppercase tracking-widest">Supports Logic Tags</span>
               </div>
               <textarea rows={6} value={payload.content} onChange={e => setPayload({...payload, content: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-3xl p-8 text-sm focus:border-indigo-500 outline-none transition-all resize-none leading-relaxed font-medium" />
            </div>
          </div>

          <button onClick={sendWebhook} disabled={sending} className="w-full py-8 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xl uppercase tracking-[0.3em] rounded-3xl shadow-[0_20px_60px_rgba(79,70,229,0.3)] transition-all active:scale-[0.97] flex items-center justify-center gap-6 group">
             {sending ? 'Broadcasting...' : <><Send className="w-8 h-8 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /> Execute Protocol</>}
          </button>
        </div>

        {/* Visualizer Panel */}
        <div className="lg:col-span-5 sticky top-10 h-fit space-y-10">
          <div className="bg-[#1e1f22] rounded-[40px] overflow-hidden shadow-[0_40px_100px_rgba(0,0,0,0.6)] border border-zinc-800">
            <div className="p-6 bg-zinc-950/80 backdrop-blur-md flex items-center justify-between border-b border-zinc-900">
              <div className="flex gap-2.5">
                <div className="w-3.5 h-3.5 rounded-full bg-[#ff5f57] shadow-lg"></div>
                <div className="w-3.5 h-3.5 rounded-full bg-[#ffbd2e] shadow-lg"></div>
                <div className="w-3.5 h-3.5 rounded-full bg-[#27c93f] shadow-lg"></div>
              </div>
              <div className="flex items-center gap-3">
                 <div className="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></div>
                 <span className="text-[10px] font-black text-zinc-400 tracking-[0.4em] uppercase italic">Quantum Gateway Preview</span>
              </div>
            </div>
            
            <div className="p-12 bg-[#313338] min-h-[550px] custom-scrollbar overflow-y-auto max-h-[800px]">
              {activeTab === 'json' ? (
                <div className="animate-in fade-in zoom-in-95 duration-500">
                  <CodeBlock code={JSON.stringify(payload, null, 2)} language="json" />
                </div>
              ) : (
                <div className="flex gap-6 animate-in slide-in-from-bottom-4 duration-700">
                   <div className="w-14 h-14 bg-zinc-800 rounded-[18px] flex-shrink-0 flex items-center justify-center text-zinc-600 border border-zinc-700/50 shadow-inner">
                     <Layers className="w-7 h-7" />
                   </div>
                   <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                         <span className="font-bold text-white text-base hover:underline cursor-pointer">{payload.username || 'Identity'}</span>
                         <span className="bg-[#5865f2] text-[9px] px-1.5 rounded-md font-bold uppercase text-white shadow-sm">Bot</span>
                         <span className="text-[11px] text-zinc-500 font-medium">Today at {new Date().getHours().toString().padStart(2,'0')}:{new Date().getMinutes().toString().padStart(2,'0')}</span>
                      </div>
                      <div className="text-zinc-200 text-[15px] leading-relaxed mb-5 font-medium whitespace-pre-wrap">
                        {renderPlaceholder(payload.content || '')}
                      </div>
                      
                      {/* Embeds */}
                      <div className="space-y-3 mb-6">
                        {payload.embeds?.map((emb, i) => (
                          <div key={i} className="flex max-w-lg animate-in fade-in duration-500" style={{ animationDelay: `${i*150}ms` }}>
                            <div className="w-1.5 rounded-l-md" style={{ backgroundColor: emb.color ? `#${emb.color.toString(16).padStart(6, '0')}` : '#1e1f22' }}></div>
                            <div className="flex-1 bg-[#2b2d31] p-6 rounded-r-md border border-zinc-700/30 border-l-0 shadow-2xl">
                              {emb.title && <div className="text-white font-bold text-lg mb-2">{renderPlaceholder(emb.title)}</div>}
                              {emb.description && <div className="text-[14px] text-[#dbdee1] leading-relaxed font-medium">{renderPlaceholder(emb.description)}</div>}
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Components (Buttons) */}
                      <div className="space-y-2">
                        {payload.components?.map((row, rIdx) => (
                          <div key={rIdx} className="flex flex-wrap gap-2">
                            {row.components.map((btn, bIdx) => (
                              <button 
                                key={bIdx}
                                disabled={btn.disabled}
                                className={`px-4 py-2 rounded-md text-[14px] font-bold text-white shadow-sm flex items-center gap-2 transition-transform active:scale-95 ${
                                  btn.style === ButtonStyle.PRIMARY ? 'bg-[#5865F2] hover:bg-[#4752C4]' :
                                  btn.style === ButtonStyle.SECONDARY ? 'bg-[#4E5058] hover:bg-[#6D6F78]' :
                                  btn.style === ButtonStyle.SUCCESS ? 'bg-[#248046] hover:bg-[#1A6334]' :
                                  btn.style === ButtonStyle.DANGER ? 'bg-[#DA373C] hover:bg-[#A1282D]' :
                                  'bg-[#4E5058] hover:bg-[#6D6F78]'
                                }`}
                              >
                                {btn.label}
                                {btn.style === ButtonStyle.LINK && <ExternalLink className="w-3 h-3" />}
                              </button>
                            ))}
                          </div>
                        ))}
                      </div>
                   </div>
                </div>
              )}
            </div>
          </div>

          <div className="glass-card p-8 border-zinc-800/50 bg-black/40">
            <h4 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] mb-6">Quantum Placeholder Intelligence</h4>
            <div className="grid grid-cols-2 gap-3">
               <div className="bg-zinc-950/50 p-3 rounded-xl text-[11px] font-mono border border-zinc-900 group hover:border-indigo-500/30 transition-all"><span className="text-indigo-400 font-bold">{"{user.mention}"}</span> Direct Ping</div>
               <div className="bg-zinc-950/50 p-3 rounded-xl text-[11px] font-mono border border-zinc-900 group hover:border-indigo-500/30 transition-all"><span className="text-indigo-400 font-bold">{"{guild.id}"}</span> UID</div>
               <div className="bg-zinc-950/50 p-3 rounded-xl text-[11px] font-mono border border-zinc-900 group hover:border-indigo-500/30 transition-all"><span className="text-indigo-400 font-bold">{"{time.now}"}</span> ISO8601</div>
               <div className="bg-zinc-950/50 p-3 rounded-xl text-[11px] font-mono border border-zinc-900 group hover:border-indigo-500/30 transition-all"><span className="text-indigo-400 font-bold">{"{server.icon}"}</span> Image Assets</div>
            </div>
          </div>

          {status && (
            <div className={`p-6 rounded-3xl border-2 flex items-center gap-5 animate-in slide-in-from-right-10 duration-500 shadow-2xl ${status.type === 'success' ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-400' : 'bg-red-950/20 border-red-500/30 text-red-400'}`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${status.type === 'success' ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}>
                {status.type === 'success' ? <Check className="w-7 h-7" /> : <AlertCircle className="w-7 h-7" />}
              </div>
              <div>
                <span className="text-xs font-black uppercase tracking-widest block">{status.type === 'success' ? 'Uplink Synchronized' : 'Protocol Interrupted'}</span>
                <p className="text-[10px] font-medium opacity-80 mt-0.5">{status.msg}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WebhookMaker;
