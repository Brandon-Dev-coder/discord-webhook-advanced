
import { GoogleGenAI, Type } from "@google/genai";
import { DiscordEvent, BotCommand } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateEventPayload = async (event: DiscordEvent, description: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Architect a professional high-fidelity Discord Webhook payload for the event: "${event}". 
    Context: "${description}". 
    Requirements:
    1. Utilize dynamic placeholders like {user.tag}, {guild.name}, {member.count}, {channel.mention}.
    2. Use a sophisticated color palette (decimal).
    3. Return strictly JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          username: { type: Type.STRING },
          content: { type: Type.STRING },
          embeds: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                color: { type: Type.NUMBER }
              }
            }
          }
        },
        required: ["username", "content"]
      }
    }
  });
  return JSON.parse(response.text?.trim() || '{}');
};

export const suggestWebhookScenario = async (userGoal: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Propose an elite Discord Webhook configuration for: "${userGoal}". Include detailed fields and professional formatting.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          username: { type: Type.STRING },
          content: { type: Type.STRING },
          embeds: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                color: { type: Type.NUMBER },
                fields: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      value: { type: Type.STRING },
                      inline: { type: Type.BOOLEAN }
                    },
                    required: ["name", "value"]
                  }
                }
              }
            }
          }
        },
        required: ["username", "content"]
      }
    }
  });
  return JSON.parse(response.text?.trim() || '{}');
};

export const generateBotCode = async (commands: BotCommand[], botName: string, antiNukeEnabled: boolean) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Generate a production-grade discord.js v14 bot engine named "${botName}".
    Features:
    - Commands: ${JSON.stringify(commands)}
    - Anti-Nuke Security: ${antiNukeEnabled ? 'ACTIVE (Include robust rate-limiting and audit log monitoring logic)' : 'DISABLED'}
    
    Output strictly the clean javascript code without markdown formatting.`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 }
    }
  });
  return response.text;
};

export const generateServerBlueprint = async (theme: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a detailed Discord server structure for the theme: "${theme}". Return JSON mapping categories to channel lists.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          categories: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                channels: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["name", "channels"]
            }
          }
        },
        required: ["categories"]
      }
    }
  });
  return JSON.parse(response.text?.trim() || '{}');
};

export const helpCraftBotMessage = async (message: string, tone: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Polish this Discord bot message to a "${tone}" tone: "${message}".`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          content: { type: Type.STRING },
          embed: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              color: { type: Type.NUMBER }
            }
          }
        },
        required: ["content"]
      }
    }
  });
  return JSON.parse(response.text?.trim() || '{}');
};

// Refine a command idea into structured properties
export const helpRefineCommand = async (input: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Refine this Discord bot command idea: "${input}". Provide a command name, description, and response template.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          description: { type: Type.STRING },
          response: { type: Type.STRING }
        },
        required: ["name", "description", "response"]
      }
    }
  });
  return JSON.parse(response.text?.trim() || '{}');
};

// Provide detailed security information about a specific Discord bot vulnerability or defense pattern
export const getSecurityInsights = async (topic: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Provide deep security insights and defensive coding patterns for Discord bots regarding: "${topic}". Return in Markdown format.`,
  });
  return response.text;
};

// Transform a message into a complete Webhook payload with potential embeds
export const helpCraftWebhookMessage = async (message: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Transform this input into a professional Discord Webhook message payload: "${message}".`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          username: { type: Type.STRING },
          content: { type: Type.STRING },
          embeds: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                color: { type: Type.NUMBER }
              }
            }
          }
        },
        required: ["username", "content"]
      }
    }
  });
  return JSON.parse(response.text?.trim() || '{}');
};
