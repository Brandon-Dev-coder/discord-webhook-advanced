
export interface WebhookEmbedField {
  name: string;
  value: string;
  inline?: boolean;
}

export interface WebhookEmbed {
  title?: string;
  description?: string;
  url?: string;
  color?: number;
  footer?: { text: string; icon_url?: string };
  image?: { url: string };
  thumbnail?: { url: string };
  author?: { name: string; url?: string; icon_url?: string };
  fields?: WebhookEmbedField[];
}

export enum ComponentType {
  ACTION_ROW = 1,
  BUTTON = 2,
  STRING_SELECT = 3,
}

export enum ButtonStyle {
  PRIMARY = 1,
  SECONDARY = 2,
  SUCCESS = 3,
  DANGER = 4,
  LINK = 5,
}

export interface WebhookButton {
  type: ComponentType.BUTTON;
  style: ButtonStyle;
  label: string;
  custom_id?: string;
  url?: string;
  disabled?: boolean;
}

export interface WebhookActionRow {
  type: ComponentType.ACTION_ROW;
  components: WebhookButton[];
}

export interface WebhookPayload {
  username?: string;
  avatar_url?: string;
  content?: string;
  embeds?: WebhookEmbed[];
  components?: WebhookActionRow[];
}

export enum DiscordEvent {
  GENERIC = 'GENERIC',
  MEMBER_JOIN = 'MEMBER_JOIN',
  MEMBER_LEAVE = 'MEMBER_LEAVE',
  MEMBER_BAN = 'MEMBER_BAN',
  SERVER_BOOST = 'SERVER_BOOST',
  MESSAGE_EDIT = 'MESSAGE_EDIT',
  MESSAGE_DELETE = 'MESSAGE_DELETE',
  LEVEL_UP = 'LEVEL_UP',
  SECURITY_ALERT = 'SECURITY_ALERT',
  VOICE_JOIN = 'VOICE_JOIN',
  THREAD_CREATE = 'THREAD_CREATE',
  REACTION_ADD = 'REACTION_ADD'
}

export interface WebhookTemplate {
  id: string;
  name: string;
  purpose: string;
  trigger: DiscordEvent;
  webhookUrl?: string;
  payload: WebhookPayload;
  createdAt: number;
}

export interface SavedWebhook {
  id: string;
  name: string;
  url: string;
}

export interface WebhookChatEntry {
  id: string;
  webhookId: string;
  webhookName: string;
  timestamp: number;
  payload: WebhookPayload;
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  WEBHOOK_MAKER = 'WEBHOOK_MAKER',
  WEBHOOK_CONSOLE = 'WEBHOOK_CONSOLE',
  UTILITIES = 'UTILITIES',
  BOT_MAKER = 'BOT_MAKER'
}

export interface BotCommand {
  id: string;
  name: string;
  description: string;
  response: string;
  type: 'text' | 'embed';
}

export type BotStatus = 'online' | 'idle' | 'dnd' | 'invisible';
export type BotActivity = 'PLAYING' | 'STREAMING' | 'LISTENING' | 'WATCHING';

export interface BotPresence {
  status: BotStatus;
  activityName: string;
  activityType: BotActivity;
}
